import Hero from "./Hero";
import Core from "./Core";
import AboutUs from "./AboutUs";
import Trust from "./Trust";

export { Hero, Core, AboutUs, Trust };